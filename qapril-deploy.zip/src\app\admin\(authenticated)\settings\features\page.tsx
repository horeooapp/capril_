import { prisma } from "@/lib/prisma";
import FeatureManager from "@/components/admin/FeatureManager";
import { Settings2, Info } from "lucide-react";
import { auth } from "@/auth";
import { redirect } from "next/navigation";

export const metadata = {
  title: "Gestion des Modules | QAPRIL Admin",
  description: "Activer ou désactiver les fonctionnalités du système.",
};

export default async function FeaturesPage() {
  const session = await auth();
  
  // Les admins et super admins peuvent gérer les features
  if (session?.user?.role !== "SUPER_ADMIN" && session?.user?.role !== "ADMIN") {
    redirect("/admin");
  }

  // Récupérer les flags de la DB (avec auto-seed si vide ou table manquante)
  let features = [];
  try {
    if ((prisma as any).featureFlag) {
      features = await (prisma as any).featureFlag.findMany({
        orderBy: { id: "asc" }
      });

      // Validation d'auto-seed intelligente
      const defaultFeatures = [
        { id: "M01-M03", name: "Vérification KYC", description: "Gestion des documents d'identité et niveaux de certification", enabled: true },
        { id: "M04", name: "Gestion des Baux", description: "Émission et suivi des contrats de location certifiés", enabled: true },
        { id: "M05", name: "Mandats de Gestion", description: "Gestion des délégations entre propriétaires et agences", enabled: true },
        { id: "M06-M09", name: "Maintenance & Incidents", description: "Suivi des interventions techniques et signalements locataires", enabled: true },
        { id: "M10-M11", name: "Médiation & Contentieux", description: "Centre de résolution amiable et procédures contentieuses", enabled: true },
        { id: "M16", name: "Fiscalité Immobilière", description: "Calcul automatique des taxes et aide à la déclaration", enabled: true },
        { id: "M-PGW", name: "Passerelle de Paiement", description: "Intégration Mobile Money (Orange, Wave, MTN) et Cartes Bancaires", enabled: true },
        { id: "DIASPORA_PACKAGE", name: "Pack Diaspora", description: "Fonctionnalités premium pour les propriétaires résidant à l'étranger", enabled: true },
        { id: "M-EDL", name: "États des Lieux", description: "EDL numériques avec photos et signature certifiée", enabled: true },
        { id: "M-SIGN", name: "Signature Électronique", description: "Service de signature légale pour tous les documents", enabled: true },
        { id: "NEWS_TICKER", name: "News Ticker", description: "Informations défilantes sur le tableau de bord", enabled: true },
        { id: "SMS_NOTIFICATIONS", name: "Notifications SMS", description: "Alertes automatiques par SMS et WhatsApp", enabled: true },
        { id: "LANDING_PAGE", name: "Page d'Accueil Marketing", description: "Vitrine publique d'agence immobilière personnalisée", enabled: true },
        { id: "CDC_CONSIGNATION", name: "Consignation CDC", description: "Dépôts des cautions et garanties légales (Caisse des Dépôts)", enabled: true },
        { id: "ASSURANCE_LOYER", name: "Assurance Loyers Impayés", description: "Souscription directe et vérification d'éligibilité locataire", enabled: true },
        { id: "M16_ANAH", name: "Aides à la Rénovation", description: "Dossiers de demande de subventions et primes de rénovation", enabled: true },
        { id: "USSD_PORTAL", name: "Portail USSD", description: "Accès hors-ligne via syntaxe USSD pour locataires", enabled: true },
        { id: "M_COLOC", name: "Gestion Colocation", description: "Gestion des baux multiples solidaire et quittances divisées", enabled: true },
        { id: "M_TERRAIN", name: "Terrains Nus & Foncier", description: "Baux fonciers, emphytéotiques et gestion des parcelles", enabled: true },
        { id: "M-CAND", name: "Dossiers Candidats", description: "Pipeline d'acquisition, scoring et choix du locataire", enabled: true },
        { id: "M-CHARGES", name: "Régularisation des Charges", description: "Calcul annuel, indexation et récupération au tantième", enabled: true },
        { id: "M-ANNONCES", name: "Diffusion Multi-Portail", description: "Interface avec les plateformes de petites annonces", enabled: true },
        { id: "M-COMPTA", name: "Comptabilité Syndic/Gérant", description: "Journaux comptables, rapprochement bancaire et bilans", enabled: true },
        { id: "M-AGENDA", name: "Agenda & Visites", description: "Planification des visites agences et interventions techniques", enabled: true }
      ];

      // S'il manque des features, on les ajoute
      if (features.length < defaultFeatures.length) {
        const featureIds = new Set(features.map((f: any) => f.id));
        const missingFeatures = defaultFeatures.filter((f: any) => !featureIds.has(f.id));
        
        if (missingFeatures.length > 0) {
          await Promise.all(missingFeatures.map((f: any) =>
            (prisma as any).featureFlag.upsert({
              where: { id: f.id },
              update: {},
              create: f,
            })
          ));
          features = await (prisma as any).featureFlag.findMany({ orderBy: { id: "asc" } });
        }
      }
    }
  } catch (e) {
    console.error("[FeaturesPage] Impossible d'accéder à la table FeatureFlag :", e);
  }

  return (
    <div className="space-y-10 pb-12">
      {/* Header Premium - Alignement Charte P01/P02 */}
      <div className="flex flex-col gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-amber-600 text-[12px] font-black uppercase tracking-[0.3em]">
            <Settings2 className="w-4 h-4" />
            <span>Paramètres Système</span>
          </div>
          {/* H1 Charte : 24sp / Bleu Nuit #1F4E79 */}
          <h1 className="text-[24sp] md:text-[32px] font-black tracking-tight text-slate-800 uppercase">
            Gestion du <span className="text-amber-600">Cœur</span>
          </h1>
          {/* Body Charte : 16sp */}
          <p className="text-[16px] text-gray-500 max-w-2xl font-medium leading-relaxed">
            Activez ou désactivez les modules applicatifs en temps réel. Ces changements affectent l'ensemble de la plateforme.
          </p>
        </div>
      </div>

      {/* Alerte Information - Couleurs Charte (Bleu Ciel Info #D6E4F0) */}
      <div className="bg-[#D6E4F0]/30 border border-[#D6E4F0] p-8 rounded-[32px] flex items-start gap-5">
        <div className="p-3 bg-slate-800 rounded-2xl text-white self-start shadow-md">
          <Info className="w-6 h-6" />
        </div>
        <div className="space-y-2">
          {/* H2 Charte : 20sp / Orange #C55A11 */}
          <h4 className="text-[20px] font-bold text-amber-600">Précaution d'Usage</h4>
          <p className="text-[16px] text-slate-800/80 leading-relaxed font-medium">
            La désactivation d'un module masquera les interfaces correspondantes pour tous les utilisateurs (Locataires, Propriétaires, Agences) mais ne supprimera pas les données en base.
          </p>
        </div>
      </div>

      {/* Liste des Modules */}
      <FeatureManager initialFeatures={features} />

      {/* Pied de page technique */}
      <div className="pt-8 border-t border-gray-100">
        <div className="flex flex-col md:flex-row justify-between gap-4 text-[10px] items-center text-gray-300 font-black uppercase tracking-widest">
          <span>QAPRIL OS v3.2 Core</span>
          <div className="flex gap-6">
            <span className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Système de Toggle Actif
            </span>
            <span>Ref: QAPRIL/DEB/2026-FT</span>
          </div>
        </div>
      </div>
    </div>
  );
}
